# Beta test checklist

Use a clean game install for the first pass. Keep
`IshimuraStabilityPatch.log` from every failed run.

## Startup and compatibility

- Test EA App, Steam, and GOG separately when available.
- Test a CPU with more than 10 logical processors without Process Lasso,
  msconfig limits, or a special launcher.
- Confirm the main menu loads five consecutive times.
- Test with no controller, an Xbox controller, and Steam Input/DS4Windows.

## Physics acceptance test

Keep the default 60 FPS safety settings.

1. Kill two enemies in a room with loose props.
2. Walk into, stomp, melee, and kinesis-drop each corpse and prop.
3. Leave them untouched for 60 seconds.
4. Confirm there is no continuous one-direction slide, hovering, escalating
   jitter, or launch caused by a light player bump.
5. Repeat in an elevator, zero-G room, and after loading a save.

Record the same scene without the mod at uncapped/high refresh for comparison.

## Audio acceptance test

- Listen for door, weapon, stomp, enemy, locator, kinesis, and UI sounds.
- Play every audio/video log found in two chapters.
- Confirm dialogue is present during the opening, tram calls, and a chapter
  transition.
- Pause/unpause, alt-tab, and change rooms during a playing log.
- Test stereo and the user's real surround layout. A missing center channel due
  to Windows speaker configuration is separate from a timing/streaming bug.

## Display and graphics

- With in-game VSync on, confirm full-refresh presentation and a 60 FPS safety
  limit rather than the vanilla 30 FPS half-refresh cap.
- With in-game VSync off, confirm the mod still limits to 60 FPS.
- Test windowed+borderless, exclusive fullscreen, alt-tab, and two monitors.
- Inspect UI, holograms, shadows, video playback, and world textures with
  anisotropic filtering on and off.

## Subtitle regression checks

- Test subtitles at 1280x720, 1920x1080, 2560x1440, and 3840x2160.
- Confirm long subtitles wrap normally, stay at two lines, and are not clipped.
- Change resolution while the game is running and retest.

## Release gate

Do not call the mod final until the physics and audio tests pass on at least
EA App and Steam/GOG, with ReShade or DXVK, an Xbox controller, and a complete
playthrough. Until then, publish it as Beta and describe exactly what was tested.
