# Ishimura Stability Patch

An original compatibility and bug-fix mod for **Dead Space (2008)**. The
default configuration favors correct game behavior over very high frame rates.

This is a **Beta** build. Its code and package can be audited and smoke-tested
without the game, but corpse interaction, chapter scripting, every streamed
sound, controllers, and every store build still require real playthrough tests.

## What it fixes

- **Modern CPU startup compatibility:** constrains the game to eight allowed
  logical processors before its unsafe legacy CPU enumeration runs. It respects
  the process's existing allowed mask instead of assuming CPUs 0-7 exist.
- **Physics and audio timing safety:** caps presentation to 60 FPS by default.
  This prevents the high-FPS timestep from producing drifting/floating bodies,
  unstable ragdolls, skipped script windows, and dropped queued sound events.
- **VSync:** converts the game's half-refresh D3D9 interval to one refresh,
  while respecting the player's choice to disable VSync.
- **Borderless windowed:** applies borderless geometry only when D3D confirms
  that the game is windowed, and uses the monitor containing the game window.
- **Texture filtering:** upgrades linear min/mag filters to supported
  anisotropic filtering and point mip filtering to trilinear. It leaves
  deliberately point-sampled textures alone.
- **Subtitle scaling:** applies one resolution scale to both subtitle layout
  and final drawing, so wrapping and rendering stay synchronized.
- **Controller-safe XInput proxy:** forwards all named XInput 1.3 functions and
  private ordinals 100-103 to Windows. It does not replace controller input,
  start SDL, or patch mouse behavior.

## Important differences from DeadSpace2008Fixes

This project does **not** enable the game's hidden global high-resolution timer
flag. That broad clock change is not a complete Havok fix and can change timing
for physics, scripts, streaming, and sound. It also does not globally hook
Winsock, NetBIOS, DirectInput, or Windows window-creation functions.

Native PlayStation/Switch translation, telemetry blocking, legacy-HID removal,
save-string replacement, and cutscene/loading skips are intentionally not in
this first bug-fix release. They are separate features, and adding them to the
timing-critical core would make controller, audio, or compatibility regressions
harder to isolate. A candidate save-string replacement was rejected during
real EA-build testing because it caused a reproducible access violation.

## Install

1. Remove or rename the existing `xinput1_3.dll`, `SDL3.dll`, and
   `DeadSpaceFixes.ini` from the game folder. Do not run both mods together.
2. Copy this archive's files beside `Dead Space.exe`.
3. In Dead Space, set display mode to **Windowed** if you want borderless mode.
4. Launch normally through EA App, Steam, GOG, or Vortex.
5. Check `IshimuraStabilityPatch.log` in the game folder.

To uninstall, remove this mod's `xinput1_3.dll`, INI, log, and documentation.
Restore any previous proxy DLL only if you deliberately backed it up.

## Recommended settings

Keep these values for stable physics and sound:

```ini
[Timing]
PhysicsAndAudioSafety=1
MaxFPS=60
AllowUnsafeHighFPS=0
```

Setting `AllowUnsafeHighFPS=1` makes high-FPS physics/audio bugs possible again
and is not considered a supported configuration.

## Compatibility

- Built as a 32-bit DLL for the 32-bit game.
- Targets Windows 7 SP1 or later and uses the static MSVC runtime.
- Designed to coexist with D3D9 wrappers by changing the game device's current
  COM vtable instead of detouring D3D9 machine code.
- Do not combine it with another `xinput1_3.dll` proxy or another subtitle hook.
- ReShade/DXVK compatibility must be confirmed on real machines before a final
  release claim.

## Source and build

Run `build.ps1 -Package` in a PowerShell prompt with Visual Studio C++ Build
Tools installed. It builds Release Win32, verifies the XInput exports and
forwarding path, and creates a versioned ZIP in the workspace `outputs` folder.

See `THIRD_PARTY_NOTICES.md` for credited research references. No game file or
third-party binary is distributed.
